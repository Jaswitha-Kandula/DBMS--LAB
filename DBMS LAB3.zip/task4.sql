use taxation_db;
show tables;
select t.name, ir.income_source from taxpayer t inner join income_record ir on t.taxpayer_id=ir.taxpayer_id;

select t.name, ic.category_name from taxpayer t inner join income_record ir on t.taxpayer_id=ir.taxpayer_id inner join income_category ic on ir.category_id=ic.category_id;

select ir.record_id,fy.year_label from income_record ir inner join finantial_year fy on ir.year_id=fy.year_id;

select t.name, t.annual_income, ir.income_amount
from taxpayer t inner join income_record ir on t.taxpayer_id=ir.taxpayer_id;

select t.name, ir.income_source, ic.category_name, fy.year_label
from taxpayer t inner join income_record ir on t.taxpayer_id=ir.taxpayer_id inner join income_category ic on ir.category_id=ic.category_id inner join finantial_year fy on ir.year_id=fy.year_id;



